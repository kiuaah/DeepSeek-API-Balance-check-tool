package com.deepseek.balance;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final String API_URL = "https://api.deepseek.com/user/balance";
    private static final String PLATFORM_URL = "https://platform.deepseek.com/";
    private static final String PREFS_NAME = "deepseek_balance";
    private static final String PREF_KEY = "api_key";
    private static final long DEFAULT_REFRESH_MS = 15000L;
    private static final String PREF_REFRESH_INTERVAL = "refresh_interval_ms";
    private static final long[] REFRESH_INTERVALS = {1000L, 5000L, 10000L, 15000L, 30000L, 60000L, 300000L, 600000L, 900000L};
    private static final String[] REFRESH_LABELS = {"1 秒", "5 秒", "10 秒", "15 秒", "30 秒", "1 分钟", "5 分钟", "10 分钟", "15 分钟"};
    private static final long[] BACKGROUND_REFRESH_INTERVALS = {1000L, 5000L, 10000L, 30000L, 60000L, 300000L, 600000L, 1800000L, 3600000L};
    private static final String[] BACKGROUND_REFRESH_LABELS = {"1 秒", "5 秒", "10 秒", "30 秒", "1 分钟", "5 分钟", "10 分钟", "30 分钟", "1 小时"};

    private static final int COLOR_BG = Color.rgb(11, 11, 12);
    private static final int COLOR_CARD = Color.rgb(20, 20, 22);
    private static final int COLOR_INPUT = Color.rgb(15, 15, 17);
    private static final int COLOR_BORDER = Color.rgb(45, 45, 49);
    private static final int COLOR_TEXT = Color.rgb(245, 245, 247);
    private static final int COLOR_MUTED = Color.rgb(161, 161, 170);
    private static final int COLOR_HINT = Color.rgb(113, 113, 122);
    private static final int COLOR_BUTTON = Color.rgb(229, 231, 235);
    private static final int COLOR_BUTTON_TEXT = Color.rgb(15, 15, 17);
    private static final int COLOR_STATUS = Color.rgb(39, 39, 42);
    private static final int COLOR_PEAK = Color.rgb(220, 38, 38);
    private static final int COLOR_PEAK_BG = Color.rgb(45, 18, 21);
    private static final int COLOR_PEAK_BORDER = Color.rgb(127, 29, 29);

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable autoRefreshRunnable = new Runnable() {
        @Override
        public void run() {
            if (isFinishing()) {
                return;
            }
            updatePeakCard();
            String apiKey = keyInput == null ? "" : keyInput.getText().toString().trim();
            if (!loading && !TextUtils.isEmpty(apiKey)) {
                queryBalance(true);
            } else {
                scheduleAutoRefresh(refreshIntervalMs);
            }
        }
    };

    private final Runnable secondTickRunnable = new Runnable() {
        @Override
        public void run() {
            updatePeakCard();
            scheduleSecondTick();
        }
    };

    private SharedPreferences preferences;
    private EditText keyInput;
    private CheckBox rememberKey;
    private TextView queryButton;
    private TextView statusView;
    private TextView balanceView;
    private TextView todayUsageView;
    private TextView detailsView;
    private TextView autoStatusView;
    private TextView peakTitleView;
    private TextView peakRemainingView;
    private TextView peakTimeView;
    private long refreshIntervalMs = DEFAULT_REFRESH_MS;
    private long backgroundRefreshIntervalMs = WidgetUpdater.DEFAULT_BACKGROUND_REFRESH_MS;
    private boolean loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        refreshIntervalMs = preferences.getLong(PREF_REFRESH_INTERVAL, DEFAULT_REFRESH_MS);
        backgroundRefreshIntervalMs = preferences.getLong(WidgetUpdater.PREF_BACKGROUND_REFRESH_INTERVAL, WidgetUpdater.DEFAULT_BACKGROUND_REFRESH_MS);
        WidgetRefreshScheduler.scheduleMidnight(this);
        configureWindow();
        buildInterface();
        loadSavedKey();
        updatePeakCard();
        HolidayUpdater.updateIfNeeded(this, changed -> runOnUiThread(this::updatePeakCard));
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(COLOR_BG);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        if (Build.VERSION.SDK_INT >= 28) {
            window.setNavigationBarDividerColor(COLOR_BG);
        }
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setScrollbarFadingEnabled(true);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(COLOR_BG);
        scroll.setPadding(dp(20), dp(22), dp(20), dp(22));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));


        TextView kicker = text("DEEPSEEK API", 11, COLOR_MUTED, Typeface.BOLD);
        kicker.setLetterSpacing(0.18f);
        content.addView(kicker, matchWrap(0));

        TextView title = text("余额查询", 31, COLOR_TEXT, Typeface.BOLD);
        title.setIncludeFontPadding(false);
        content.addView(title, matchWrap(8));

        TextView subtitle = text("通过官方开放平台实时读取账户余额", 14, COLOR_MUTED, Typeface.NORMAL);
        subtitle.setLineSpacing(0f, 1.15f);
        content.addView(subtitle, matchWrap(8));

        LinearLayout keyCard = card();
        content.addView(keyCard, matchWrap(28));

        TextView keyLabel = text("API KEY", 11, COLOR_MUTED, Typeface.BOLD);
        keyLabel.setLetterSpacing(0.12f);
        keyCard.addView(keyLabel, matchWrap(0));

        keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setTextSize(15);
        keyInput.setTextColor(COLOR_TEXT);
        keyInput.setHintTextColor(COLOR_HINT);
        keyInput.setHint("sk-...");
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        keyInput.setBackground(roundRect(COLOR_INPUT, COLOR_BORDER, 12, 1));
        keyInput.setPadding(dp(14), dp(13), dp(14), dp(13));
        keyInput.setSelectAllOnFocus(false);
        if (Build.VERSION.SDK_INT >= 26) {
            keyInput.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        }
        keyCard.addView(keyInput, matchWrap(12));

        LinearLayout rememberRow = new LinearLayout(this);
        rememberRow.setOrientation(LinearLayout.HORIZONTAL);
        rememberRow.setGravity(Gravity.CENTER_VERTICAL);
        keyCard.addView(rememberRow, matchWrap(8));

        rememberKey = new CheckBox(this);
        rememberKey.setText("记住密钥");
        rememberKey.setTextSize(13);
        rememberKey.setTextColor(COLOR_MUTED);
        rememberKey.setButtonTintList(ColorStateList.valueOf(COLOR_BUTTON));
        rememberKey.setPadding(0, 0, 0, 0);
        rememberRow.addView(rememberKey, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView localOnly = text("仅存本机", 12, COLOR_HINT, Typeface.NORMAL);
        rememberRow.addView(localOnly, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        queryButton = actionButton("查询余额", true);
        keyCard.addView(queryButton, matchHeight(50, 18));

        autoStatusView = text("进入自动查询 · 每 " + refreshIntervalLabel() + "刷新", 11, COLOR_HINT, Typeface.NORMAL);
        autoStatusView.setGravity(Gravity.CENTER);
        autoStatusView.setClickable(true);
        autoStatusView.setFocusable(true);
        autoStatusView.setContentDescription("点击更换前台刷新频率，长按更换后台刷新频率");
        autoStatusView.setOnClickListener(v -> showRefreshIntervalDialog());
        autoStatusView.setOnLongClickListener(v -> {
            showBackgroundRefreshDialog();
            return true;
        });
        keyCard.addView(autoStatusView, matchWrap(12));

        LinearLayout resultCard = card();
        content.addView(resultCard, matchWrap(16));

        statusView = text("等待查询", 11, COLOR_MUTED, Typeface.BOLD);
        statusView.setGravity(Gravity.CENTER);
        statusView.setLetterSpacing(0.08f);
        statusView.setBackground(roundRect(COLOR_STATUS, COLOR_BORDER, 99, 1));
        statusView.setPadding(dp(12), dp(7), dp(12), dp(7));
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        resultCard.addView(statusView, statusParams);

        LinearLayout balanceRow = new LinearLayout(this);
        balanceRow.setOrientation(LinearLayout.HORIZONTAL);
        balanceRow.setGravity(Gravity.CENTER_VERTICAL);
        resultCard.addView(balanceRow, matchWrap(16));

        LinearLayout balanceColumn = new LinearLayout(this);
        balanceColumn.setOrientation(LinearLayout.VERTICAL);
        balanceRow.addView(balanceColumn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        balanceView = text("—", 26, COLOR_TEXT, Typeface.BOLD);
        balanceView.setIncludeFontPadding(false);
        balanceView.setLetterSpacing(-0.02f);
        TextView cnyLabel = text("CNY 余额", 11, COLOR_HINT, Typeface.NORMAL);
        balanceColumn.addView(cnyLabel, matchWrap(0));

        balanceColumn.addView(balanceView, matchWrap(4));

        LinearLayout usageColumn = new LinearLayout(this);
        usageColumn.setOrientation(LinearLayout.VERTICAL);
        usageColumn.setGravity(Gravity.END);
        balanceRow.addView(usageColumn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView usageLabel = text("今日用量", 11, COLOR_MUTED, Typeface.NORMAL);
        usageLabel.setGravity(Gravity.END);
        usageColumn.addView(usageLabel, matchWrap(0));

        todayUsageView = text("—", 26, COLOR_TEXT, Typeface.BOLD);
        todayUsageView.setGravity(Gravity.END);
        usageColumn.addView(todayUsageView, matchWrap(4));

        detailsView = text("等待读取 CNY 余额", 13, COLOR_MUTED, Typeface.NORMAL);
        detailsView.setLineSpacing(dp(4), 1.1f);
        resultCard.addView(detailsView, matchWrap(12));


        LinearLayout peakCard = card();
        content.addView(peakCard, matchWrap(16));

        TextView peakLabel = text("谷峰时段", 11, COLOR_MUTED, Typeface.BOLD);
        peakLabel.setLetterSpacing(0.12f);
        peakCard.addView(peakLabel, matchWrap(0));

        LinearLayout peakStatusRow = new LinearLayout(this);
        peakStatusRow.setOrientation(LinearLayout.HORIZONTAL);
        peakStatusRow.setGravity(Gravity.CENTER_VERTICAL);
        peakCard.addView(peakStatusRow, matchWrap(10));

        peakTitleView = text("—", 20, COLOR_TEXT, Typeface.BOLD);
        peakStatusRow.addView(peakTitleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout remainingColumn = new LinearLayout(this);
        remainingColumn.setOrientation(LinearLayout.VERTICAL);
        remainingColumn.setGravity(Gravity.END);
        remainingColumn.setMinimumWidth(dp(92));
        peakStatusRow.addView(remainingColumn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView remainingLabel = text("剩余时间", 11, COLOR_MUTED, Typeface.NORMAL);
        remainingLabel.setGravity(Gravity.END);
        remainingColumn.addView(remainingLabel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        peakRemainingView = text("", 20, COLOR_MUTED, Typeface.BOLD);
        peakRemainingView.setGravity(Gravity.END);
        peakRemainingView.setSingleLine(true);
        peakRemainingView.setMinWidth(dp(92));
        LinearLayout.LayoutParams remainingParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        remainingParams.topMargin = dp(2);
        remainingColumn.addView(peakRemainingView, remainingParams);

        peakTimeView = text("", 11, COLOR_HINT, Typeface.NORMAL);
        peakCard.addView(peakTimeView, matchWrap(4));




        TextView platformButton = actionButton("进入 DeepSeek 开放平台  ↗", false);
        platformButton.setContentDescription("打开 DeepSeek 开放平台");
        content.addView(platformButton, matchHeight(52, 16));

        TextView privacy = text(
                "密钥仅发送给 api.deepseek.com。勾选“记住密钥”后，密钥只保存在本机应用私有存储中。",
                11,
                COLOR_HINT,
                Typeface.NORMAL);
        privacy.setGravity(Gravity.CENTER);
        privacy.setLineSpacing(dp(2), 1.15f);
        content.addView(privacy, matchWrap(18));

        setContentView(scroll);
        applyInsets(scroll);

        queryButton.setOnClickListener(v -> queryBalance(false));
        platformButton.setOnClickListener(v -> openPlatform());
        keyInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                queryBalance(false);
                return true;
            }
            return false;
        });
        keyInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (rememberKey.isChecked()) {
                    saveKey(s.toString().trim());
                }
            }
        });
        rememberKey.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                saveKey(keyInput.getText().toString().trim());
            } else {
                preferences.edit().remove(PREF_KEY).apply();
            }
        });
    }

    private void applyInsets(View root) {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
                Insets bars = windowInsets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(dp(20), dp(22) + bars.top, dp(20), dp(22) + bars.bottom);
                return windowInsets;
            });
            root.requestApplyInsets();
        }
    }

    private void loadSavedKey() {
        String savedKey = preferences.getString(PREF_KEY, "");
        if (!TextUtils.isEmpty(savedKey)) {
            keyInput.setText(savedKey);
            keyInput.setSelection(savedKey.length());
            rememberKey.setChecked(true);
        }
    }

    private void queryBalance(boolean automatic) {
        if (loading) {
            return;
        }

        String apiKey = keyInput.getText().toString().trim();
        if (TextUtils.isEmpty(apiKey)) {
            if (automatic) {
                scheduleAutoRefresh(refreshIntervalMs);
                return;
            }
            Toast.makeText(this, "请先输入 DeepSeek API Key", Toast.LENGTH_SHORT).show();
            keyInput.requestFocus();
            return;
        }

        keyInput.clearFocus();
        autoStatusView.setText(automatic ? "正在自动查询…" : "正在查询…");
        setLoading(true);
        scheduleAutoRefresh(refreshIntervalMs);

        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(API_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Authorization", "Bearer " + apiKey);
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", "DeepSeekBalance/1.0 Android");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(15000);

                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300
                        ? connection.getInputStream()
                        : connection.getErrorStream();
                String body = readText(stream);

                if (code == 200) {
                    BalanceData data = parseBalance(body);
                    runOnUiThread(() -> showBalance(data));
                } else {
                    String message;
                    if (code == 401) {
                        message = "API Key 无效或已失效";
                    } else if (code == 403) {
                        message = "当前密钥没有余额查询权限";
                    } else if (code == 429) {
                        message = "请求过于频繁，请稍后再试";
                    } else {
                        message = "请求失败（HTTP " + code + "）";
                    }
                    String finalMessage = message;
                    runOnUiThread(() -> showError(finalMessage));
                }
            } catch (Exception exception) {
                String message = exception instanceof IOException
                        ? "网络连接失败，请检查网络后重试"
                        : "数据解析失败，请稍后重试";
                runOnUiThread(() -> showError(message));
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        });
    }

    private BalanceData parseBalance(String body) throws JSONException {
        JSONObject root = new JSONObject(body);
        boolean available = root.optBoolean("is_available", false);
        JSONArray balances = root.optJSONArray("balance_infos");

        if (balances != null) {
            for (int index = 0; index < balances.length(); index++) {
                JSONObject item = balances.optJSONObject(index);
                if (item == null) {
                    continue;
                }
                String currency = item.optString("currency", "").trim();
                if (!"CNY".equalsIgnoreCase(currency)) {
                    continue;
                }
                String total = item.optString("total_balance", "0").trim();
                String usage = UsageTracker.recordBalance(getApplicationContext(), total);
                return new BalanceData(available, formatAmount(total, "CNY"), "CNY", usage);
            }
        }

        throw new JSONException("未找到 CNY 余额");
    }

    private String refreshIntervalLabel() {
        for (int index = 0; index < REFRESH_INTERVALS.length; index++) {
            if (REFRESH_INTERVALS[index] == refreshIntervalMs) {
                return REFRESH_LABELS[index];
            }
        }
        return REFRESH_LABELS[3];
    }

    private void showRefreshIntervalDialog() {
        int selected = 3;
        for (int index = 0; index < REFRESH_INTERVALS.length; index++) {
            if (REFRESH_INTERVALS[index] == refreshIntervalMs) {
                selected = index;
                break;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("刷新频率")
                .setSingleChoiceItems(REFRESH_LABELS, selected, (dialog, which) -> {
                    refreshIntervalMs = REFRESH_INTERVALS[which];
                    preferences.edit().putLong(PREF_REFRESH_INTERVAL, refreshIntervalMs).apply();
                    autoStatusView.setText("每 " + refreshIntervalLabel() + "刷新");
                    scheduleAutoRefresh(refreshIntervalMs);
                    dialog.dismiss();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showBackgroundRefreshDialog() {
        int selected = 6;
        for (int index = 0; index < BACKGROUND_REFRESH_INTERVALS.length; index++) {
            if (BACKGROUND_REFRESH_INTERVALS[index] == backgroundRefreshIntervalMs) {
                selected = index;
                break;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("后台查询频率")
                .setSingleChoiceItems(BACKGROUND_REFRESH_LABELS, selected, (dialog, which) -> {
                    backgroundRefreshIntervalMs = BACKGROUND_REFRESH_INTERVALS[which];
                    preferences.edit().putLong(WidgetUpdater.PREF_BACKGROUND_REFRESH_INTERVAL, backgroundRefreshIntervalMs).apply();
                    Toast.makeText(this, "后台查询频率：" + BACKGROUND_REFRESH_LABELS[which], Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void updatePeakCard() {
        if (peakTitleView == null) {
            return;
        }
        PeakTimeUtils.Status status = PeakTimeUtils.currentStatus(this);
        peakTitleView.setText(status.title);
        if (status.peak) {
            peakTitleView.setTextColor(COLOR_PEAK);
        } else {
            peakTitleView.setTextColor(COLOR_MUTED);
        }
        peakRemainingView.setText(status.remaining);
        peakRemainingView.setVisibility(status.remaining.isEmpty() ? View.GONE : View.VISIBLE);
        peakTimeView.setText(status.currentTime);
    }

    private void showBalance(BalanceData data) {
        setLoading(false);
        statusView.setText(data.available ? "账户可用" : "账户不可用");
        statusView.setTextColor(data.available ? COLOR_TEXT : COLOR_MUTED);
        statusView.setBackground(roundRect(COLOR_STATUS, COLOR_BORDER, 99, 1));
        balanceView.setText(data.totalDisplay);
        todayUsageView.setText(data.todayUsage);
        detailsView.setVisibility(android.view.View.GONE);
        WidgetUpdater.saveSnapshot(this, data.totalDisplay, data.todayUsage);
        autoStatusView.setText("每 " + refreshIntervalLabel() + "刷新 · 更新于 " + currentTime());
    }

    private void showError(String message) {
        setLoading(false);
        statusView.setText("查询失败");
        statusView.setTextColor(COLOR_TEXT);
        statusView.setBackground(roundRect(COLOR_STATUS, COLOR_BORDER, 99, 1));
        balanceView.setText("—");
        todayUsageView.setText("—");
        detailsView.setVisibility(android.view.View.VISIBLE);
        detailsView.setText(message);
        autoStatusView.setText("每 " + refreshIntervalLabel() + "刷新 · 本次失败，稍后重试");
    }

    private void setLoading(boolean value) {
        loading = value;
        queryButton.setEnabled(!value);
        queryButton.setAlpha(value ? 0.55f : 1f);
        keyInput.setEnabled(!value);
        rememberKey.setEnabled(!value);
        if (value) {
            queryButton.setText("查询中…");
            statusView.setText("正在读取");
            statusView.setTextColor(COLOR_MUTED);
            balanceView.setText("…");
            todayUsageView.setText("…");
            detailsView.setVisibility(android.view.View.VISIBLE);
            detailsView.setText("正在读取 CNY 余额与今日用量");
        } else {
            queryButton.setText("查询余额");
        }
    }

    private void saveKey(String key) {
        if (TextUtils.isEmpty(key)) {
            preferences.edit().remove(PREF_KEY).apply();
            return;
        }
        preferences.edit().putString(PREF_KEY, key).apply();
    }

    private void openPlatform() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(PLATFORM_URL));
            startActivity(intent);
        } catch (Exception exception) {
            Toast.makeText(this, "未找到可用浏览器", Toast.LENGTH_SHORT).show();
        }
    }

    private String readText(InputStream stream) throws IOException {
        if (stream == null) {
            return "";
        }
        try (InputStream input = new BufferedInputStream(stream);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            return new String(output.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private String formatAmount(String amount, String currency) {
        if (TextUtils.isEmpty(amount)) {
            return "—";
        }
        if ("CNY".equalsIgnoreCase(currency)) {
            return "¥" + amount;
        }
        if ("USD".equalsIgnoreCase(currency)) {
            return "$" + amount;
        }
        return TextUtils.isEmpty(currency) ? amount : amount + " " + currency;
    }

    private String currencyLabel(String currency) {
        if (TextUtils.isEmpty(currency)) {
            return "";
        }
        return currency + "  ";
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(roundRect(COLOR_CARD, COLOR_BORDER, 18, 1));
        card.setElevation(dp(1));
        return card;
    }

    private TextView actionButton(String label, boolean primary) {
        TextView button = text(label, 15, primary ? COLOR_BUTTON_TEXT : COLOR_TEXT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setClickable(true);
        button.setFocusable(true);
        button.setPadding(dp(16), dp(14), dp(16), dp(14));
        button.setBackground(primary
                ? roundRect(COLOR_BUTTON, 0, 14, 0)
                : roundRect(COLOR_INPUT, COLOR_BORDER, 14, 1));
        return button;
    }

    private TextView text(String value, float size, int color, int style) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.create("sans-serif", style));
        return view;
    }

    private GradientDrawable roundRect(int fillColor, int borderColor, int radiusDp, int borderDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(radiusDp));
        if (borderDp > 0) {
            drawable.setStroke(dp(borderDp), borderColor);
        }
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap(int topMarginDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(topMarginDp);
        return params;
    }

    private LinearLayout.LayoutParams matchHeight(int heightDp, int topMarginDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(heightDp));
        params.topMargin = dp(topMarginDp);
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void scheduleAutoRefresh(long delayMs) {
        handler.removeCallbacks(autoRefreshRunnable);
        handler.postDelayed(autoRefreshRunnable, delayMs);
    }

    private String currentTime() {
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    private void scheduleSecondTick() {
        long now = SystemClock.uptimeMillis();
        handler.postAtTime(secondTickRunnable, now + (1000L - (now % 1000L)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        WidgetRefreshScheduler.cancel(this);
        updatePeakCard();
        handler.removeCallbacks(secondTickRunnable);
        scheduleSecondTick();
        String apiKey = keyInput == null ? "" : keyInput.getText().toString().trim();
        if (!loading && !TextUtils.isEmpty(apiKey)) {
            queryBalance(true);
        } else {
            scheduleAutoRefresh(refreshIntervalMs);
        }
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(autoRefreshRunnable);
        handler.removeCallbacks(secondTickRunnable);
        WidgetRefreshScheduler.schedule(this);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private static final class BalanceData {
        final boolean available;
        final String totalDisplay;
        final String details;
        final String todayUsage;

        BalanceData(boolean available, String totalDisplay, String details, String todayUsage) {
            this.available = available;
            this.totalDisplay = totalDisplay;
            this.details = details;
            this.todayUsage = todayUsage;
        }
    }
}
