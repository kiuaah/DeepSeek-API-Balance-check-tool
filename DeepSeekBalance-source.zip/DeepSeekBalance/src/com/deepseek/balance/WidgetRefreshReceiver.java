package com.deepseek.balance;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class WidgetRefreshReceiver extends BroadcastReceiver {
    private static final String BALANCE_URL = "https://api.deepseek.com/user/balance";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            WidgetRefreshScheduler.schedule(context);
            WidgetRefreshScheduler.scheduleMidnight(context);
            return;
        }

        final boolean midnight = WidgetRefreshScheduler.ACTION_MIDNIGHT.equals(action);
        if (!midnight && !WidgetRefreshScheduler.ACTION_REFRESH.equals(action)) {
            return;
        }

        final PendingResult pendingResult = goAsync();
        final Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                if (midnight || WidgetUpdater.hasWidgets(appContext)) {
                    refresh(appContext);
                }
            } finally {
                if (midnight) {
                    WidgetRefreshScheduler.scheduleMidnight(appContext);
                } else if (WidgetUpdater.hasWidgets(appContext)) {
                    WidgetRefreshScheduler.schedule(appContext);
                }
                pendingResult.finish();
            }
        });
    }

    private static void refresh(Context context) {
        String apiKey = WidgetUpdater.getApiKey(context);
        if (apiKey.isEmpty()) {
            return;
        }
        String balance = fetchCnyBalance(apiKey);
        if (balance != null) {
            String usage = UsageTracker.recordBalance(context, balance);
            WidgetUpdater.saveSnapshot(context, "¥" + balance, usage);
        }
    }

    private static String fetchCnyBalance(String apiKey) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(BALANCE_URL).openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
            connection.setRequestProperty("Accept", "application/json");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            if (connection.getResponseCode() != 200) {
                return null;
            }

            JSONObject root = new JSONObject(readText(connection.getInputStream()));
            JSONArray balances = root.optJSONArray("balance_infos");
            if (balances == null) {
                return null;
            }
            for (int index = 0; index < balances.length(); index++) {
                JSONObject item = balances.optJSONObject(index);
                if (item != null && "CNY".equalsIgnoreCase(item.optString("currency", ""))) {
                    return item.optString("total_balance", "0").trim();
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return null;
    }

    private static String readText(InputStream stream) throws Exception {
        if (stream == null) {
            return "";
        }
        try (InputStream input = new BufferedInputStream(stream);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[2048];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            return new String(output.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
