package com.deepseek.balance;

import android.content.Context;
import android.content.SharedPreferences;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class UsageTracker {
    private static final String PREF_USAGE_DATE = "usage_date";
    private static final String PREF_LAST_BALANCE = "usage_last_balance";
    private static final String PREF_TOTAL_USAGE = "usage_total";

    private UsageTracker() {
    }

    static String recordBalance(Context context, String rawBalance) {
        BigDecimal current;
        try {
            current = new BigDecimal(rawBalance).setScale(2, RoundingMode.HALF_UP);
        } catch (Exception exception) {
            return "—";
        }

        SharedPreferences preferences = context.getSharedPreferences(
                WidgetUpdater.PREFS_NAME, Context.MODE_PRIVATE);
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        String savedDate = preferences.getString(PREF_USAGE_DATE, "");
        String lastRaw = preferences.getString(PREF_LAST_BALANCE, "");
        String totalRaw = preferences.getString(PREF_TOTAL_USAGE, "0.00");
        BigDecimal total;

        try {
            total = new BigDecimal(totalRaw).setScale(2, RoundingMode.HALF_UP);
        } catch (Exception exception) {
            total = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }

        if (!today.equals(savedDate) || lastRaw.isEmpty()) {
            total = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        } else {
            try {
                BigDecimal last = new BigDecimal(lastRaw).setScale(2, RoundingMode.HALF_UP);
                if (current.compareTo(last) < 0) {
                    total = total.add(last.subtract(current)).setScale(2, RoundingMode.HALF_UP);
                }
            } catch (Exception ignored) {
            }
        }

        preferences.edit()
                .putString(PREF_USAGE_DATE, today)
                .putString(PREF_LAST_BALANCE, current.toPlainString())
                .putString(PREF_TOTAL_USAGE, total.toPlainString())
                .putString(WidgetUpdater.PREF_USAGE, "¥" + total.toPlainString())
                .apply();
        return "¥" + total.toPlainString();
    }
}
