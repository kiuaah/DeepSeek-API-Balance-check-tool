# DeepSeek 余额

极简原生 Android 应用，用于查询 DeepSeek API 账户余额，并提供 DeepSeek 开放平台入口。

当前版本为 `1.0.10`：只显示 CNY 总余额，每次进入应用立即查询，之后每 15 秒刷新。

## 功能

- 输入 DeepSeek API Key 后点击“查询余额”
- 每次进入或回到应用时立即查询一次
- 应用在前台时每 15 秒自动查询一次
- 应用退到后台后停止自动查询
- 当前页面直接查询官方余额接口
- 只读取并显示 CNY 总余额
- 余额卡片右侧显示今日用量
- 提供 4×2、2×2、2×1 三种桌面小组件
- 小组件只显示当前余额和今日用量，没有查询按钮
- 不在后台定时唤醒；只有查询余额或点击小组件时才更新
- 今日用量优先读取 DeepSeek 平台汇总接口，无权限时显示 —
- 一键进入 `https://platform.deepseek.com/`
- 可选“记住密钥”，仅保存在应用私有存储中
- 黑 / 灰配色，无第三方依赖
- 顶部不显示鲸鱼图标，桌面启动图标保持 DeepSeek 黑白鲸鱼

## 安装

将 `DeepSeekBalance.apk` 发送到 Android 手机并安装。内部版本号高于崩溃测试版本，可直接覆盖安装；包名与签名保持一致。

如果系统仍拒绝覆盖，请先卸载崩溃版本再安装。卸载前注意：已保存的 API Key 会被清除。

## 使用

1. 在 DeepSeek 开放平台创建 API Key。
2. 在应用中粘贴 API Key。
3. 点击“查询余额”，或等待应用每 15 秒自动查询。
4. 点击下方按钮可直接打开 DeepSeek 开放平台。

## 安全说明

- API Key 只发送给 `https://api.deepseek.com`。
- 勾选“记住密钥”时，密钥保存在应用私有 `SharedPreferences` 中。
- 不要将 API Key 分享给他人；如密钥泄露，请立即在开放平台删除并重新创建。
- 当前 APK 使用 Android 调试证书签名，适合个人安装使用。

## 构建

项目使用纯 Android SDK 工具构建，不需要 Gradle。项目目录结构：

```text
DeepSeekBalance/
├── AndroidManifest.xml
├── build.ps1
├── README.md
├── src/com/deepseek/balance/MainActivity.java
└── res/
    ├── drawable/ic_launcher.xml
    └── values/
        ├── strings.xml
        └── styles.xml
```

构建命令：

```powershell
.\build.ps1
```
